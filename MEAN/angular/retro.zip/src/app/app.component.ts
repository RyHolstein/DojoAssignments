import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  colors = randomColor();
  numbers = [1,2,3,4,5,6,7,8];
}


function randomColor(){
  var colorArray: string[] = [];
  for (var i = 1; i < 10 ; i++){
    let rand_num: string = "#";
    for (var j = 1; j< 7; j++){
      let thisNumber: string = String((Math.floor(Math.random()* 8 )) + 1);
      rand_num = rand_num + thisNumber
    }
    colorArray.push(rand_num);
  }
  return colorArray
}
