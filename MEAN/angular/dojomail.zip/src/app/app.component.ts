import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  loggedIn = true;
  emails = [
    {Email:"johnny@yahoo.com", importance: true, subject: "Love", content: "i need you in my life"},
    {Email:"kasey@yahoo.com", importance: true, subject: "The Goods", content: "where are the goods"},
    {Email:"dillon@yahoo.com", importance: false, subject: "The need", content: "The need is the want and the want is the need"},
    {Email:"billgates@yahoo.com", importance: true, subject: "Money", content: "I need to borrow some more"},
    {Email:"johnnycash@yahoo.com", importance: false, subject: "Music", content: "I need some more music my main man"},
    {Email:"katie@yahoo.com", importance:  false, subject: "Love", content: "i miss you so much come back to me"},
  ];

}
